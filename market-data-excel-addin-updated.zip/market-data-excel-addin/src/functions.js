/* Demo custom functions. Replace demoProvider methods with your authenticated backend API. */
const demoQuotes = {
  AAPL: { price: 224.50, change: 2.35, changePercent: 1.06, open: 221.10, high: 225.20, low: 220.50, volume: 58120345, marketCap: 3400000000000, pe: 34.2, week52High: 237.49 },
  MSFT: { price: 415.30, change: -1.25, changePercent: -0.30, open: 416.50, high: 418.20, low: 412.10, volume: 22345678, marketCap: 3080000000000, pe: 35.1, week52High: 468.35 },
  RELIANCE: { price: 1382.40, change: 8.10, changePercent: 0.59, open: 1374.20, high: 1391.00, low: 1369.10, volume: 5123400, marketCap: 18600000000000, pe: 24.8, week52High: 1608.80 }
};
const quoteFor = (symbol) => demoQuotes[String(symbol || '').trim().toUpperCase()] || demoQuotes.AAPL;

/** @customfunction */
function QUOTE(symbol, field) {
  const key = String(field || 'price').trim();
  const quote = quoteFor(symbol);
  if (!(key in quote)) throw new Error(`Unknown quote field: ${key}`);
  return quote[key];
}
QUOTE.id = 'QUOTE'; QUOTE.name = 'SANTOSH.QUOTE'; QUOTE.description = 'Returns a market quote field for a symbol.';
QUOTE.parameters = [{ name: 'symbol', description: 'Market symbol, for example AAPL.', type: 'string' }, { name: 'field', description: 'Field such as price, change, open, high, low, volume.', type: 'string' }];

/** @customfunction */
function HISTORY(symbol, startDate, endDate, interval, field) {
  const allowed = ['close', 'open', 'high', 'low', 'volume'];
  const requestedField = String(field || 'close').toLowerCase();
  if (!allowed.includes(requestedField)) throw new Error(`Unknown history field: ${requestedField}`);
  const start = new Date(`${startDate}T00:00:00Z`), end = new Date(`${endDate}T00:00:00Z`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || start > end) throw new Error('Use valid dates and ensure start date is not after end date.');
  const step = String(interval || '1d').toLowerCase() === '1mo' ? 30 : String(interval || '1d').toLowerCase() === '1wk' ? 7 : 1;
  const base = quoteFor(symbol).price;
  const rows = [['Date', requestedField[0].toUpperCase() + requestedField.slice(1)]];
  let i = 0;
  for (let d = new Date(start); d <= end && i < 500; d.setUTCDate(d.getUTCDate() + step), i++) {
    const wave = Math.sin(i * 0.73) * base * 0.018 + Math.cos(i * 0.31) * base * 0.009;
    let value = base + wave;
    if (requestedField === 'open') value -= 0.5;
    if (requestedField === 'high') value += 1.2;
    if (requestedField === 'low') value -= 1.4;
    if (requestedField === 'volume') value = Math.round(15000000 + Math.abs(Math.sin(i)) * 35000000);
    rows.push([d.toISOString().slice(0, 10), requestedField === 'volume' ? value : Number(value.toFixed(2))]);
  }
  return rows;
}
HISTORY.id = 'HISTORY'; HISTORY.name = 'SANTOSH.HISTORY'; HISTORY.description = 'Returns historical market data as a dynamic array.';
HISTORY.parameters = [{ name: 'symbol', description: 'Market symbol.', type: 'string' }, { name: 'startDate', description: 'Start date YYYY-MM-DD.', type: 'string' }, { name: 'endDate', description: 'End date YYYY-MM-DD.', type: 'string' }, { name: 'interval', description: '1d, 1wk, or 1mo.', type: 'string' }, { name: 'field', description: 'close, open, high, low, volume.', type: 'string' }];

/** @customfunction */
function NEWS(symbolOrKeyword, limit, period) {
  const term = String(symbolOrKeyword || 'Market').trim();
  const max = Math.max(1, Math.min(50, Number(limit) || 10));
  const headlines = [
    ['Technology shares mixed as investors assess earnings outlook', `${term} and peers remain in focus as markets digest the latest company updates.`, 'Market Desk', new Date().toISOString().slice(0, 10), 'https://example.com/demo-news-1'],
    ['Analysts watch growth, margins, and guidance', `Investors are tracking new information related to ${term} and the wider sector.`, 'Business Wire (demo)', new Date(Date.now() - 86400000).toISOString().slice(0, 10), 'https://example.com/demo-news-2'],
    ['Market update: trading volume and volatility in focus', `Market participants continue to monitor activity around ${term}.`, 'Financial News (demo)', new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10), 'https://example.com/demo-news-3']
  ];
  return [['Title', 'Summary', 'Source', 'Published Date', 'URL'], ...headlines.slice(0, max)];
}
NEWS.id = 'NEWS'; NEWS.name = 'SANTOSH.NEWS'; NEWS.description = 'Returns recent market news as a dynamic array.';
NEWS.parameters = [{ name: 'symbolOrKeyword', description: 'Symbol or keyword.', type: 'string' }, { name: 'limit', description: 'Maximum number of rows.', type: 'number' }, { name: 'period', description: 'Date range such as 7d or 30d.', type: 'string' }];

if (typeof CustomFunctions !== 'undefined') {
  CustomFunctions.associate('QUOTE', QUOTE);
  CustomFunctions.associate('HISTORY', HISTORY);
  CustomFunctions.associate('NEWS', NEWS);
}
