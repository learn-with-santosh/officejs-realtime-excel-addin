const $ = (selector) => document.querySelector(selector);
const state = { tab: 'quote', fields: new Set(['price', 'change', 'changePercent']), output: 'single' };
const quoteFields = [ ['price','Price'], ['change','Change'], ['changePercent','% Change'], ['open','Open'], ['high','High'], ['low','Low'], ['volume','Volume'], ['marketCap','Market Cap'], ['pe','P/E Ratio'], ['week52High','52-Week High'] ];
const demoQuote = { price:224.50, change:2.35, changePercent:1.06, open:221.10, high:225.20, low:220.50, volume:58120345 };
function setStatus(message, error=false) { $('#statusText').textContent = message; $('#statusDot').classList.toggle('error', error); }
function getSymbol() { return ($('#symbol')?.value || 'AAPL').trim().toUpperCase(); }
function selectedFields() { return [...(state.fields || [])]; }
function quoteFormula(symbol, field) { return `=SANTOSH.QUOTE("${symbol}","${field}")`; }
function historyFormula() { return `=SANTOSH.HISTORY("${getSymbol()}","${$('#startDate').value}","${$('#endDate').value}","${$('#interval').value}","${$('#historyField').value}")`; }
function newsFormula() { return `=SANTOSH.NEWS("${($('#newsTerm')?.value || 'AAPL').trim()}",${Number($('#limit').value || 10)},"${$('#period').value}")`; }
function render() {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === state.tab));
  const root = $('#workspace');
  if (state.tab === 'quote') root.innerHTML = quoteView();
  else if (state.tab === 'history') root.innerHTML = historyView();
  else if (state.tab === 'news') root.innerHTML = newsView();
  else root.innerHTML = templatesView();
  bindView();
}
function quoteView() {
  return `<section class="intro"><div class="icon-tile">▥</div><div><h1>Get Quote</h1><p>Get market data for any supported symbol.</p></div></section>
  <label for="symbol">Symbol</label><input id="symbol" value="AAPL" placeholder="e.g. AAPL, MSFT, RELIANCE" autocomplete="off" />
  <div class="label-row"><label>Data fields</label><span class="muted" id="fieldCount">3 selected</span></div>
  <div class="field-grid">${quoteFields.map(([key,label])=>`<label class="check-row"><input type="checkbox" data-field="${key}" ${state.fields.has(key)?'checked':''}/><span>${label}</span><code>${key}</code></label>`).join('')}</div>
  <div class="section-title">Output options</div><label class="radio-row"><input type="radio" name="output" value="single" ${state.output==='single'?'checked':''}/> <span><b>Single value per formula</b><small>Each selected field gets its own cell.</small></span></label><label class="radio-row"><input type="radio" name="output" value="table" ${state.output==='table'?'checked':''}/> <span><b>Multiple fields (table)</b><small>One formula returns a two-column field/value array.</small></span></label>
  <label for="targetCell">Insert at cell</label><input id="targetCell" value="A1" placeholder="A1"/>
  <div class="preview-head"><span>Formula preview</span><button id="copyFormula" class="text-button">Copy</button></div><pre id="formulaPreview"></pre>
  <div class="button-row"><button class="primary" id="insertButton">↳ Insert Function</button><button class="secondary" id="previewButton">◉ Preview Data</button></div>
  <div id="previewResult" class="preview-result hidden"></div><p class="hint">Demo mode uses sample data. Connect your market-data provider in <code>src/functions.js</code> for live data.</p>`;
}
function historyView() {
  return `<section class="intro"><div class="icon-tile">▦</div><div><h1>Historical Data</h1><p>Build a date-based market data series.</p></div></section>
  <label for="symbol">Symbol</label><input id="symbol" value="AAPL" placeholder="e.g. AAPL"/><div class="two-col"><div><label for="startDate">Start date</label><input id="startDate" type="date" value="2026-10-01"/></div><div><label for="endDate">End date</label><input id="endDate" type="date" value="2026-10-19"/></div></div>
  <label for="interval">Time interval</label><select id="interval"><option value="1d">Daily</option><option value="1wk">Weekly</option><option value="1mo">Monthly</option></select><label for="historyField">Data field</label><select id="historyField"><option value="close">Close</option><option value="open">Open</option><option value="high">High</option><option value="low">Low</option><option value="volume">Volume</option></select>
  <div class="preview-head"><span>Formula preview</span><button id="copyFormula" class="text-button">Copy</button></div><pre id="formulaPreview"></pre><div class="button-row"><button class="primary" id="insertButton">↳ Insert Function</button><button class="secondary" id="previewButton">◉ Preview Data</button></div><div id="previewResult" class="preview-result hidden"></div><p class="hint">The history function returns a dynamic array. Make sure the destination spill area is empty.</p>`;
}
function newsView() {
 return `<section class="intro"><div class="icon-tile">▤</div><div><h1>Get News</h1><p>Insert a structured news feed.</p></div></section><label for="newsTerm">Symbol or keyword</label><input id="newsTerm" value="AAPL" placeholder="Company, symbol, or topic"/><div class="two-col"><div><label for="period">Date range</label><select id="period"><option value="7d">Last 7 days</option><option value="30d">Last 30 days</option><option value="1d">Last 24 hours</option></select></div><div><label for="limit">Maximum results</label><select id="limit"><option>5</option><option selected>10</option><option>20</option><option>50</option></select></div></div><div class="section-title">Output fields</div><div class="field-grid">${['Title','Summary','Source','Published Date','URL'].map(x=>`<label class="check-row"><input type="checkbox" checked disabled/><span>${x}</span></label>`).join('')}</div><div class="preview-head"><span>Formula preview</span><button id="copyFormula" class="text-button">Copy</button></div><pre id="formulaPreview"></pre><div class="button-row"><button class="primary" id="insertButton">↳ Insert Function</button><button class="secondary" id="previewButton">◉ Preview Data</button></div><div id="previewResult" class="preview-result hidden"></div><p class="hint">News rows are demo placeholders until you connect a news provider.</p>`;
}
function templatesView() {
 const templates=[['Quick Quote Sheet','Insert symbol, price, change, % change, and volume columns.','table'],['Multi-Symbol Watchlist','Create a starter watchlist for AAPL, MSFT, and RELIANCE.','watchlist'],['Historical Chart Data','Insert a historical date and close-price series.','history'],['Latest News Feed','Insert a structured recent-news feed.','news']];
 return `<section class="intro"><div class="icon-tile">▱</div><div><h1>Templates</h1><p>Start with a ready-made workbook layout.</p></div></section>${templates.map(([title,desc,key])=>`<article class="template-card"><div class="template-icon">${key==='history'?'▦':key==='news'?'▤':'▤'}</div><div class="template-copy"><b>${title}</b><p>${desc}</p></div><button class="add-template" data-template="${key}" title="Insert template">＋</button></article>`).join('')}<p class="hint">Templates write formulas into the active worksheet. Existing cells are not intentionally cleared.</p>`;
}
function currentFormula() {
 if (state.tab==='quote') { const symbol=getSymbol(); const fields=selectedFields(); if (!symbol || !fields.length) return '# Select a symbol and at least one field'; if(state.output==='single') return fields.map(f=>quoteFormula(symbol,f)).join('\n'); return `=SANTOSH.QUOTE("${symbol}","${fields[0]}")  // Choose single-value mode for separate fields`; }
 if(state.tab==='history') return historyFormula();
 if(state.tab==='news') return newsFormula();
 return '';
}
function updatePreview() {
 const p=$('#formulaPreview'); if(p) p.textContent=currentFormula();
 const count=$('#fieldCount'); if(count) count.textContent=`${state.fields.size} selected`;
}
function bindView() {
 const symbol=$('#symbol'); if(symbol) symbol.addEventListener('input', updatePreview);
 document.querySelectorAll('[data-field]').forEach(cb=>cb.addEventListener('change',()=>{ if(cb.checked)state.fields.add(cb.dataset.field);else state.fields.delete(cb.dataset.field);updatePreview(); }));
 document.querySelectorAll('input[name="output"]').forEach(r=>r.addEventListener('change',()=>{state.output=r.value;updatePreview();}));
 ['startDate','endDate','interval','historyField','newsTerm','limit','period'].forEach(id=>{const el=$('#'+id);if(el)el.addEventListener('change',updatePreview);});
 const copy=$('#copyFormula'); if(copy)copy.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(currentFormula());setStatus('Formula copied');}catch(e){setStatus('Copy failed; select the formula text to copy',true);}});
 const insert=$('#insertButton');if(insert)insert.addEventListener('click',insertFormula);
 const preview=$('#previewButton');if(preview)preview.addEventListener('click',showPreview);
 document.querySelectorAll('[data-template]').forEach(b=>b.addEventListener('click',()=>insertTemplate(b.dataset.template)));
 updatePreview();
}
async function insertFormula() {
 const address=$('#targetCell')?.value?.trim() || '';
 const formulas=[];
 if(state.tab==='quote') {
   const fields=selectedFields(); if(!getSymbol()||!fields.length){setStatus('Enter a symbol and select at least one field',true);return;}
   if(state.output==='single') fields.forEach((field,i)=>formulas.push({offset:i,formula:quoteFormula(getSymbol(),field)}));
   else { setStatus('Table output is not yet supported by the current QUOTE signature. Select single value mode.',true);return; }
 } else if(state.tab==='history') formulas.push({offset:0,formula:historyFormula()});
 else if(state.tab==='news') formulas.push({offset:0,formula:newsFormula()});
 else return;
 if (!window.Excel || !Office?.context) {setStatus('Open this task pane inside Excel to insert formulas',true);return;}
 try {
   await Excel.run(async context=>{
     const sheet=context.workbook.worksheets.getActiveWorksheet();
     let startRange;
     if(address) startRange=sheet.getRange(address); else startRange=context.workbook.getSelectedRange();
     if(state.tab==='quote' && state.output==='single' && formulas.length>1) {
       const matrix=formulas.map(x=>[x.formula]);
       startRange.getResizedRange(matrix.length-1,0).formulas=matrix;
     } else startRange.formulas=[[formulas[0].formula]];
     await context.sync();
   }); setStatus('Formula inserted into Excel');
 } catch(error) {setStatus(`Insert failed: ${error.message || error}`,true);}
}
function showPreview() {
 const box=$('#previewResult'); if(!box)return;box.classList.remove('hidden');
 if(state.tab==='quote') { const fields=selectedFields();box.innerHTML=`<b>Sample preview · ${escapeHtml(getSymbol())}</b><div class="preview-table">${fields.map(f=>`<div><span>${escapeHtml(f)}</span><b>${demoQuote[f]===undefined?'—':Number(demoQuote[f]).toLocaleString('en-US')}</b></div>`).join('')}</div>`; }
 else if(state.tab==='history') box.innerHTML='<b>Sample preview</b><div class="preview-table"><div><span>Date</span><b>Close</b></div><div><span>2026-10-01</span><b>222.31</b></div><div><span>2026-10-02</span><b>225.02</b></div><div><span>2026-10-05</span><b>223.88</b></div></div>';
 else box.innerHTML='<b>Sample preview</b><div class="preview-table"><div><span>Title</span><b>Market update (demo)</b></div><div><span>Source</span><b>Market Desk</b></div><div><span>Published</span><b>Today</b></div></div>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function insertTemplate(key) {
 if(!window.Excel){setStatus('Open this task pane inside Excel to insert templates',true);return;}
 const rows=[];
 if(key==='table'||key==='watchlist') {
   rows.push(['Symbol','Price','Change','% Change','Volume']);
   const symbols=key==='watchlist'?['AAPL','MSFT','RELIANCE']:['AAPL'];
   symbols.forEach((s,i)=>{const r=i+2;rows.push([s,`=SANTOSH.QUOTE(A${r},"price")`,`=SANTOSH.QUOTE(A${r},"change")`,`=SANTOSH.QUOTE(A${r},"changePercent")`,`=SANTOSH.QUOTE(A${r},"volume")`]);});
 } else if(key==='history') {rows.push(['Date','Close']);rows.push([`=SANTOSH.HISTORY("AAPL","2026-10-01","2026-10-19","1d","close")`,'']);}
 else if(key==='news') {rows.push([`=SANTOSH.NEWS("AAPL",10,"7d")`]);}
 try{await Excel.run(async context=>{const sheet=context.workbook.worksheets.getActiveWorksheet();const start=context.workbook.getSelectedRange();const destination=start.getResizedRange(rows.length-1,Math.max(...rows.map(r=>r.length))-1);destination.formulas=rows.map(r=>{const padded=[...r];while(padded.length<destination.columnCount)padded.push('');return padded;});await context.sync();});setStatus('Template inserted');}catch(e){setStatus(`Template insert failed: ${e.message||e}`,true);}
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{state.tab=b.dataset.tab;render();}));
$('#settingsButton').addEventListener('click',()=>{setStatus('Settings: demo provider enabled. Configure your API adapter in src/functions.js.');});
if (typeof Office !== 'undefined' && Office.onReady) Office.onReady(info=>{if(info.host===Office.HostType.Excel)setStatus('Connected to Excel · Demo data mode');else setStatus('Ready · Open in Excel to insert formulas');render();}); else render();
