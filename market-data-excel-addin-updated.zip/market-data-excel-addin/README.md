# Market Data Excel Add-in (Office.js)

An Office.js Excel task-pane add-in with Quote, History, News, and Templates screens. It includes three custom functions:

- `=SANTOSH.QUOTE("AAPL","price")`
- `=SANTOSH.HISTORY("AAPL","2026-10-01","2026-10-19","1d","close")`
- `=SANTOSH.NEWS("AAPL",10,"7d")`

## Important: demo data vs. live data

This project is a runnable starter, not a live market-data service. The included functions return **mock/demo data**. Unknown symbols currently fall back to AAPL sample data so the UI is easy to test. News headlines and links are explicitly demo placeholders. Do not use demo outputs for investment or production decisions. Connect a licensed market-data provider through a backend before using real data. Keep API keys on the backend, never in this add-in's JavaScript.

## Requirements

- Node.js 20+ and npm
- Microsoft Excel on Windows or Mac that supports Office Add-ins and custom functions
- Internet access to load the official Office.js library

## Run locally

1. Extract this ZIP to a normal local folder.
2. Open a terminal in the project folder.
3. Install dependencies: `npm install`
4. Start the local HTTPS server and sideload the add-in into Excel: `npm start`
5. Accept/install the local development certificate if prompted. Keep the terminal open while testing.
6. In Excel, open the **Market Data** task pane from the Home ribbon. Depending on your Excel build, the add-in may appear as **Open Market Data**.
7. To stop the add-in, press `Ctrl+C` and run `npm run stop` if the debugging registration remains.

If your organization blocks sideloading, ask your Microsoft 365 administrator to enable it or use your organization's centralized deployment process.

## Build

Run `npm run build` and `npm run validate`. The production bundle is written to `dist/`. The manifest currently points at `https://localhost:3000`, so a production deployment must update manifest resource URLs to your HTTPS-hosted domain and host the bundle files there. A local build alone is not a hosted production deployment.

## Test formulas

```excel
=SANTOSH.QUOTE("AAPL","price")
=SANTOSH.QUOTE("MSFT","changePercent")
=SANTOSH.HISTORY("AAPL","2026-10-01","2026-10-19","1d","close")
=SANTOSH.NEWS("AAPL",10,"7d")
```

For `HISTORY`, dates use `YYYY-MM-DD`; interval accepts `1d`, `1wk`, or `1mo`; field accepts `close`, `open`, `high`, `low`, or `volume`. For `QUOTE`, fields are `price`, `change`, `changePercent`, `open`, `high`, `low`, `volume`, `marketCap`, `pe`, and `week52High`.

## Architecture

- `taskpane.html`, `src/taskpane.js`, `src/taskpane.css`: UI and Office.js formula insertion.
- `functions.html`, `src/functions.js`: custom functions runtime and demo provider data.
- `functions.json`: custom-function metadata.
- `manifest.xml`: task pane, ribbon button, and custom-function registration.
- `webpack.config.js`: HTTPS development server and production bundling.

## Connect a real provider

Replace the demo logic in `src/functions.js` with calls to your own HTTPS backend. The backend should handle provider credentials, authentication, caching, rate limits, symbol validation, and vendor-specific response mapping. Configure CORS and authentication carefully. Do not put vendor API secrets in the task pane or custom-functions bundle.

## Notes and limitations

- Quote returns a single numeric field. The UI inserts selected quote fields as individual formulas into vertically adjacent cells.
- History and news return two-dimensional arrays and require dynamic-array/spill support in the Excel client.
- The UI preview uses illustrative sample values and is not a live API preview.
- Template insertion and custom functions should be tested on the exact Excel versions and platforms you intend to support.
- For enterprise distribution, add SSO/authentication, telemetry with privacy controls, a proper backend, automated tests, accessibility testing, and a reviewed deployment process.

## UI design update

The task pane uses a Microsoft Office-inspired visual system: compact header, active-tab underline, blue primary actions, grouped field selectors, formula preview panels, preview data cards, and template cards. The Home ribbon exposes Market Data entry points for Quotes, History, News, and Templates. In this starter manifest these ribbon buttons open the same task pane; users choose the desired workspace using the task-pane tabs.

The ribbon uses shared add-in icons in this starter. Replace the icons in `assets/` with purpose-specific Quote, History, News, and Template glyphs for a fully branded release.
