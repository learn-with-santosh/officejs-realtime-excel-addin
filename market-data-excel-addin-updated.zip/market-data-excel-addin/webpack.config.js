const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const devCerts = require('office-addin-dev-certs');

module.exports = async (env, argv) => {
  const isDev = argv.mode !== 'production';
  const httpsOptions = isDev ? await devCerts.getHttpsServerOptions() : undefined;
  return {
    entry: {
      taskpane: './src/taskpane.js',
      functions: './src/functions.js'
    },
    output: { path: path.resolve(__dirname, 'dist'), filename: '[name].js', clean: true },
    devtool: isDev ? 'source-map' : false,
    module: { rules: [{ test: /\.js$/, exclude: /node_modules/, use: { loader: 'babel-loader', options: { presets: [['@babel/preset-env', { targets: { esmodules: true } }]] } }] },
    plugins: [new CopyWebpackPlugin({ patterns: [{ from: 'taskpane.html', to: 'taskpane.html' }, { from: 'functions.html', to: 'functions.html' }, { from: 'functions.json', to: 'functions.json' }, { from: 'src/taskpane.css', to: 'taskpane.css' }, { from: 'assets', to: 'assets' }] })],
    devServer: { port: 3000, server: { type: 'https', options: httpsOptions }, headers: { 'Access-Control-Allow-Origin': '*' }, static: { directory: path.join(__dirname, 'dist') }, hot: false, liveReload: true },
    optimization: { minimize: !isDev }
  };
};
